---
title: Changelog
---

## v1.1.0

###### Jul 29, 2021

- Add RTL (right-to-left) support
- Add TypeScript version
- Add components pages
- Add foundation pages
- Add invoice pages
- Add multi-language support
- Update landing page
- Update dashboard sidebar
- Update theme palette

## v1.0.0

###### Jul 10, 2021

Initial release.
