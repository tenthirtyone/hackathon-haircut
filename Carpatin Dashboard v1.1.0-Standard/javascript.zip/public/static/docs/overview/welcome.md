---
title: Welcome
---

# About the documentation

Welcome to the documentation for Devias - Retail & Back Office! This documentation will take you
from [getting started](getting-started)
with our kit to customizing it and making it work for your use case.

## Something Missing?

If you have ideas for more "How To" recipes that should be on this page, please, let us know or
contribute some!

## Feedback

We are always happy for you to send your feedback
at [support@deviasio.zendesk.com](mailto:support@deviasio.zendesk.com).
